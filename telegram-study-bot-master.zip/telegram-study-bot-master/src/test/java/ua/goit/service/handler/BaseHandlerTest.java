package ua.goit.service.handler;

import org.junit.Test;
import ua.goit.controller.TelegramMessageSender;
import ua.goit.view.buttons.MenuBlock;
import static org.junit.Assert.*;

public class BaseHandlerTest {
    
    /**
     * Test of handle method, of class TelegramCommandHandler.
     */
    @Test
    public void testHandle() {
        
        System.out.println("handle");
        long expectedChatId = 1;
        String callbackQuery = "/no";
        
        TelegramMessageSender telegramMessageSender = new TelegramMessageSender() {
            @Override
            public void sendNew(Long chatId, String text, Integer column, MenuBlock... menuBlock) {
                fail("Incorrect method called.");
            }
            @Override
            public void sendNew(Long chatId, String text) {
                System.out.println("MESSAGE : " + chatId + "; " + text);
                assertNotNull(text);
                assertNotNull(chatId);
                assertEquals(expectedChatId, chatId.longValue());
                assertFalse(text.isEmpty());
            }
            @Override
            public void sendNewWithReply(Long chatId, String text, Integer column, MenuBlock... menuBlock) {
                fail("Incorrect method called.");
            }
        };        
        TelegramCommandHandler.of().handle(expectedChatId, callbackQuery, telegramMessageSender);
    }
    
}
