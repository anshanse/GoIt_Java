package ua.goit.model;

@FunctionalInterface
public interface BaseEntity <ID> {

    ID getId();

}
