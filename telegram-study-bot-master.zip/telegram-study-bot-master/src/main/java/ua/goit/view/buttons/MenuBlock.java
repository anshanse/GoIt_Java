package ua.goit.view.buttons;

public interface MenuBlock {

    String getText();
    String getCommand();
}
