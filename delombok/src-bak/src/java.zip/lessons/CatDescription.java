package lessons;

public class CatDescription {
    
    private String dsc = "CatDescription"; 
    
    @Override
    public String toString() {
        return dsc;
    }
    
}
