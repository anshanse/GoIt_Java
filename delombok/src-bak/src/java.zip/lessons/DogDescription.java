package lessons;

public class DogDescription {
    
    private String dsc = "DogDescription"; 

    @Override
    public String toString() {
        return dsc;
    }
    
}
