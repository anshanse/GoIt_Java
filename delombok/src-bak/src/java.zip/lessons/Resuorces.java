package lessons;

public class Resuorces {
    public static String ANIMAL = "CAT";
}
